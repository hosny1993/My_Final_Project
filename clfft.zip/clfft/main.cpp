#include <iostream>
#include "applyfft.h"


int main()
{
    ApplyFFT *fft = new ApplyFFT(); // clfft

    size_t buffer_size = 0;
    size_t N0 = 0, N1 = 0, N2 = 0;

    high_resolution_clock::time_point t1;
    high_resolution_clock::time_point t2;
    long duration;

    float *dataVector = NULL;
    int print_iter = 0;

    /***************************************    1D    ************************************************/
    printf("1D_FFT Input :  \n");

    N0 = 8;
    buffer_size = N0 * sizeof(float*);
    dataVector = (float*) malloc (buffer_size);

    srand(time(NULL));
    while(print_iter < N0)
        {
            float x =  static_cast <float>  ( rand() % 100 ) / 100 + rand() % 100 ;
            float y =  static_cast <float>  ( rand() % 100 ) / 100 + rand() % 100 ;

            dataVector[2 * print_iter  ]   = x;
            dataVector[2 * print_iter + 1] = y ;
            printf("(%f, %f) ", x, y);
            print_iter++;
        }
        printf("\n\n");

    /************************************ excute clfft_1d ****************************************/

    dataVector = fft->_perform1DFFT(CLFFT_SINGLE, CLFFT_COMPLEX_INTERLEAVED,
                                    CLFFT_FORWARD, N0, dataVector);

    //clfft output
    printf("clfft_1d output : \n\n");

    print_iter = 0;
    while(print_iter < N0)
    {
        printf("(%f, %f) ", dataVector[2 * print_iter], dataVector[2 * print_iter + 1]);
        print_iter++;
    }
    printf("\n\n");

    free(dataVector);

    /*************************************************************************************************/
    /***************************************    2D    ************************************************/

    printf("2D_FFT Input :  \n");

    N0 = 4; N1 = 4;
    buffer_size  = N0 * N1 * 2 * sizeof(float*);
    dataVector = (float*)malloc(buffer_size);

    int i, j, k;
        i = j = 0;
        for (i=0; i < N0; ++i) {
            for (j=0; j < N1; ++j) {
                float x =  static_cast <float>  ( rand() % 100 ) / 100 + rand() % 100 ;
                float y =  static_cast <float>  ( rand() % 100 ) / 100 + rand() % 100 ;
                unsigned idx = 2 * (j + i * N0);
                dataVector[idx] = x;
                dataVector[idx + 1] = y;
                printf("(%f, %f) ", x, y);
            }
            printf("\n");
        }
    printf("\n");

    dataVector = fft->_perform2DFFT(CLFFT_SINGLE, CLFFT_COMPLEX_INTERLEAVED,
                                     CLFFT_FORWARD, N0, N1, dataVector);

    i = j = 0;
        for (i=0; i<N0; ++i)
        {
            for (j=0; j<N1; ++j)
            {
                unsigned idx = 2 * (j + i * N0);
                printf("(%f, %f) ", dataVector[idx], dataVector[idx+1]);
            }
            printf("\n");
        }
    printf("\n\n");

    free(dataVector);

    /***************************************    3D    ************************************************/

    N0 = 4; N1 = 4; N2 = 4;
    printf("3D_FFT Input :  \n");
    buffer_size  = N0 * N1 * N2 * 2 * sizeof(float*);
    dataVector = (float*)malloc(buffer_size);

        i = j = k = 0;
        for (i=0; i<N0; ++i) {
            for (j=0; j<N1; ++j) {
                for (k=0; k<N2; ++k) {
                    float x =  static_cast <float> ( ( rand() % 100 ) / 100 + rand() % 100 );
                    float y =  static_cast <float> ( ( rand() % 100 ) / 100 + rand() % 100 );
                    if (i==0 && j==0 && k==0) {
                        x = y = 0.5f;
                    }
                    unsigned idx = 2 * (k + j * N1 + i * N0 * N1);
                    dataVector[idx] = x;
                    dataVector[idx+1] = y;
                    printf("(%f, %f) ", dataVector[idx], dataVector[idx+1]);
                }
                printf("\n");
            }
            printf("\n");
        }

    dataVector = fft->_perform3DFFT(CLFFT_SINGLE, CLFFT_COMPLEX_INTERLEAVED,
                                     CLFFT_FORWARD, N0, N1, N2, dataVector);

        i = j = k = 0;
        for (i=0; i<N0; ++i) {
            for (j=0; j<N1; ++j) {
                for (k=0; k<N2; ++k) {
                    unsigned idx = 2 * (k + j * N1 + i * N0 * N1);
                    printf("(%f, %f) ", dataVector[idx], dataVector[idx+1]);
                }
                printf("\n");
            }
            printf("\n");
        }
        printf("\n\n");

    free(dataVector);

    return 0;
}
