#ifndef APPLYFFT_H
#define APPLYFFT_H
#include <clFFT.h>
#include <stdlib.h>
#include <chrono>
#include <iostream>
#include <time.h>

using namespace std::chrono;

class ApplyFFT
{

private:

    /*!
     * \brief clSetup_
     */

    cl_int err_;
    cl_uint numPlatoforms_;
    cl_uint numDevices_;

    cl_platform_id* platformID_;
    cl_device_id* deviceID_;
    cl_context context_;
    cl_command_queue commandQueue_;
    cl_mem inputBuffer_;

public:
    /*!
     * \brief ApplyFFT
     */
    ApplyFFT();

    ~ApplyFFT();

    /*!
     * \brief perform1DFFT
     * \param precision
     * \param layout
     * \param direction
     * \param sizeOfData
     * \param input reference to data vector
     * \return reference to data vector
     */
    float* _perform1DFFT(clfftPrecision precision,clfftLayout layout,
                      clfftDirection direction, size_t sizeOfData, float input[]);

    /*!
     * \brief perform2DFFT
     * \param precision
     * \param layout
     * \param direction
     * \param N1
     * \param N2
     * \param input reference to data vector
     * \return reference to data vector
     */

    /*!
     * \brief _perform2DFFT
     * \param precision
     * \param layout
     * \param direction
     * \param N1
     * \param N2
     * \param input
     * \return
     */
    float* _perform2DFFT(clfftPrecision precision, clfftLayout layout,
                                clfftDirection direction, size_t N1, size_t N2, float *input);
    /*!
     * \brief perform3DFFT
     * \param precision
     * \param layout
     * \param direction
     * \param N1
     * \param N2
     * \param N3
     * \param input reference to data vector
     * \return reference to data vector
     */
    float* _perform3DFFT(clfftPrecision precision, clfftLayout layout,
                                clfftDirection direction, size_t N1, size_t N2, size_t N3,float *input);
};

#endif // APPLYFFT_H
